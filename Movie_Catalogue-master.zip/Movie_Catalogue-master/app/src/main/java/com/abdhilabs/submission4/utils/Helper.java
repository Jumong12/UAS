package com.abdhilabs.submission4.utils;

public class Helper {
    public static final String KEY_MOVIES = "movies";
    public static final String STATE = "state";
    public static final String EXTRA_MOVIE = "movie";
    public static final String EXTRA_TV_SHOW = "tv_show";
}
